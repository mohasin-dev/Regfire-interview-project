@extends('layouts.app')

@section('title', 'Shop')

@section('content')
    <div id="app">
        <div class="container">
           <shop-component></shop-component>
        </div>
    </div>
@endsection
