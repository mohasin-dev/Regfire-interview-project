@extends('layouts.app')

@section('title', 'Home')

@section('content')
<div class="text-center">

    <div style="margin-top: 100px;">
        <h1 style="margin-bottom: 10px;">Reg<span style="color: red;">Fire</span> Solutions Limited</h1>
        <h2>Laravel & Vue.js Project</h2>
        <h5>Submitted By</h5>
        <h2>Syed Mohasin Hossain</h2>
        <h5>mohasin2911@gmail.com</h5>
        <h4>01820-937110</h4>
    </div>
</div>
@endsection

