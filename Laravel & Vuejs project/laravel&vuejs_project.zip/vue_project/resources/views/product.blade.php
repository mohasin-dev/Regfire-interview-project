@extends('layouts.app')

@section('title', 'Products')

@section('content')
    <div id="app">
        <div class="container">
           <product-component></product-component>
        </div>
    </div>
@endsection
