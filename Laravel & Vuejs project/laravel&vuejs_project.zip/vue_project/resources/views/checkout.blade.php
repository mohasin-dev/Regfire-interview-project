@extends('layouts.app')

@section('title', 'Checkout')

@section('content')
    <checkout-component></checkout-component>
@endsection
