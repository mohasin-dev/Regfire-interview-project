<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>
<div class="text-center">

    <div style="margin-top: 100px;">
        <h1 style="margin-bottom: 10px;">Reg<span style="color: red;">Fire</span> Solutions Limited</h1>
        <h2>Laravel & Vue.js Project</h2>
        <h5>Submitted By</h5>
        <h2>Syed Mohasin Hossain</h2>
        <h5>mohasin2911@gmail.com</h5>
        <h4>01820-937110</h4>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\vue_project\resources\views/welcome.blade.php ENDPATH**/ ?>