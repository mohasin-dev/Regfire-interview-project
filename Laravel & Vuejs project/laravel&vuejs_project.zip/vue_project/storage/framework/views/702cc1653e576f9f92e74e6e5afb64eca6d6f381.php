<?php $__env->startSection('title', 'Shop'); ?>

<?php $__env->startSection('content'); ?>
    <div id="app">
        <div class="container">
           <shop-component></shop-component>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\vue_project\resources\views/shop.blade.php ENDPATH**/ ?>